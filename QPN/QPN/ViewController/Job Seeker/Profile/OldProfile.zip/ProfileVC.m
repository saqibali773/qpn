//
//  ProfileVC.m
//  QPN
//
//  Created by SaqibAli on 26/01/2017.
//  Copyright © 2017 SaqibAli. All rights reserved.
//

#import "ProfileVC.h"
#import "MBProgressHUD.h"
#import "PNTToolbar.h"
#import "AppDelegate.h"
#import "ProfileOptionsCell.h"
#import "UserBioDataVC.h"
#import "UIView+Toast.h"

@interface ProfileVC ()<UISearchBarDelegate>

@end

@implementation ProfileVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
}

#pragma mark - Table Delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 6;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 55.0;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString * resuseID = @"profileOptionCell";
    ProfileOptionsCell * cell = [tableView dequeueReusableCellWithIdentifier:resuseID];
    
    if(!cell)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"ProfileOptionsCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    switch (indexPath.row)
    {
        case 0:
            cell.title.text = @"Bio Data";
            break;
        case 1:
            cell.title.text = @"Education";
            break;
        case 2:
            cell.title.text = @"Skills";
            break;
        case 3:
            cell.title.text = @"Experiance";
            break;
        case 4:
            cell.title.text = @"Achievement";
            break;
        case 5:
            cell.title.text = @"Settings";
            break;
            
        default:
            break;
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row ==1)
    {
        [tableView deselectRowAtIndexPath:indexPath animated:NO];
        
        UserBioDataVC*vc = [[UserBioDataVC alloc] initWithNibName:@"UserBioDataVC" bundle:[NSBundle mainBundle]];
        self.tabBarController.navigationController.navigationBar.hidden = NO;
        [self.tabBarController.navigationController pushViewController:vc animated:YES];
    }
    else
    {
        [self.view makeToast:@"Under Development"];
    }

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onMenuClick:(id)sender {
    AppDelegate * appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [appDelegate.rootContainer toggleLeftSideMenuCompletion:nil];

    
}




@end
